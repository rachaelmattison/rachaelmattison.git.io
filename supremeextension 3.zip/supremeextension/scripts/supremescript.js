

$('.logo').click( function() {$(this).css({"transform" : "rotate(180deg)"})}) 



$('.news_container').css ( {"background-image" : 'url("img/7762346.jpg")'})


document.body.style.border = "5px solid blue"; 



$('.news.news3.us').css( {"background-image" : 'url("https://media3.giphy.com/media/mrk2xCFr1g52/source.gif"'})

// var vid = document.createElement('iframe');



var time = document.createElement('p');
var node = document.createTextNode("   03/31/1994");
time.appendChild(node);
$('#time-zone-name').append(time)


var para2 = document.createElement('p');
var node = document.createTextNode("“I always really liked what was coming out of the skate world,” Jebbia says. “It was less commercial—it had more edge and more fuck-you type stuff.” So he decided to open his own skate shop on Lafayette Street. Lafayette was then a relatively quiet strip of antiques stores, a firehouse, and a machinist, but also a Keith Haring shop—a downtown art-scene connection that, in hindsight, was key. Jebbia built a spare space (the very notions of spare and clean soon becoming Supreme trademarks), then brought in good skateboards, cranked the music, and played videos constantly—wildly disparate things like Muhammad Ali fight videos and Taxi Driver—to draw onlookers.")
para2.appendChild(node);


// $('#left_pane').click
var para = document.createElement('p');
var node = document.createTextNode("“My thing has always been that the clothing we make is kind of like music,” Jebbia says. “There are always critics that don’t understand that young people can be into Bob Dylan but also into the Wu-Tang Clan and Coltrane and Social Distortion. Young people—and skaters—are very, very open-minded . . . to music, to art, to many things, and that allowed us to make things with an open mind.”");
para.appendChild(node);
$('#wrap').append(para)


var addy = document.createElement('h1');
var node = document.createTextNode("274 Lafayette Street New York City, NY 10029");
addy.appendChild(node);
$('#stores-list').append(addy)


var news = document.createElement('h2');
var node = document.createTextNode("19 YEAR OLD, JAMES JEBBIA OPENS UP SKATESHOP IN LOWER EAST SIDE NEW YORK CITY: APRIL 1994");
news.appendChild(node);
$('#left_pane').append(news)

$('#left_pane').css( {"background-color" : "#daff82"})




$('body').css( {"background-image" : 'url"https://d2w9rnfcy7mm78.cloudfront.net/6523134/original_f8098b8e884a079c5d204ff08a25be44.jpg?1584754252?bc=0"'})
$('#wrap').css( {"background-image" : 'url"https://d2w9rnfcy7mm78.cloudfront.net/4877544/large_d92a3d921d60da77aad57e655fa79eb9.jpg?1566491326?bc=1"'})
// $('.home us').css( (background-color).remove())?????????????


$('.home.us').css( {"background-color" : "transparent"})



$('#movie-tupac-1585658790').remove()
$('#movie-tupac-1585657574_jwplayer_display_image').remove()
$('#news_link').remove()
$('.desktop-preview').remove()
$('#collections-container').remove()
$('.store').remove()
$('.news_page_container').remove()
$('img').remove()
$('#background-image-container').remove()
$('b').remove()
$('.blurb').remove()
$('br').remove()
// $('.store').remove()
 $('#top_notice').remove()
 $('.lookbook_link').remove()
 $('.shop_link').remove()
 $('.no-right-padding').remove()
$('#right_pane').remove()
$('.turbolink_scroll_container').remove()
$('[itemprop="streetAddress"]').remove()


// $('#left_pane').prepend ({"background-image" : "url'https://d2w9rnfcy7mm78.cloudfront.net/6523134/original_f8098b8e884a079c5d204ff08a25be44.jpg?1584754252?bc=0'"})
$('#left_pane').css( {"background-color" : "none"})

$('.about.us').css( {"background-image" : 'url("https://nssdata.s3.amazonaws.com/images/galleries/19886/kids-cover-20150626452210.jpg")'})
$('.home.us').css( {"background-image" : 'url("https://nssdata.s3.amazonaws.com/images/galleries/19886/supreme-clothing-history-1.jpg")'})
$('.preview-36.layout1.us').css( {"background-image" : 'url("https://d2w9rnfcy7mm78.cloudfront.net/6523134/original_f8098b8e884a079c5d204ff08a25be44.jpg?1584754252?bc=0")'})
$('.stores.us').css( {"background-image" : 'url("https://static.highsnobiety.com/thumbor/5gU_lITJJSQ-5FQVjez2yJvR_3w=/fit-in/960x576/smart/static.highsnobiety.com/wp-content/uploads/2019/04/21135602/supreme-Lafayette-25th-anniversary-feat.jpg")'})















